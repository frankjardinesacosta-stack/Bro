# SENSI OG — alternativa de servidor Render

Se añadió `render-server/` como alternativa al backend Cloudflare, junto con `render.yaml` y `RENDER_DEPLOY_ES.md`. Lee esa guía antes de desplegar.

IMPORTANTE: Render necesita una base PostgreSQL persistente; el Blueprint usa planes de pago. No introduzcas el token de Telegram en archivos ni en GitHub.
