# Botón Abrir Free Fire MAX

Se reemplazó la imagen del botón por el banner completo proporcionado por el usuario. La imagen contiene el logo y el texto «ABRIR FREE FIRE MAX»; por eso se muestra completa con `scaledToFit`, sin recortes, gradientes ni texto superpuesto. Se conserva la acción existente `openFreeFireMax`.
